<?php 
header("Location: en/index.html"); 
?>